# Streams Plugin

The streams plugin allows you to output streams data with PyroCMS tags. It also has tools for creating entry forms and other types of content.

The streams plugin is only available as part of the [streams module](https://www.pyrocms.com/store/details/pyrostreams) or as part of [PyroCMS Pro](https://www.pyrocms.com/store/details/pyrocms_professional).

{{ nav:auto start="plugins/streams" }}