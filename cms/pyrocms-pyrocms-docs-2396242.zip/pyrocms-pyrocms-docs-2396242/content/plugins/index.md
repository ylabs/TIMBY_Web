# Plugins

Plugins are the simplest type of add-on in PyroCMS, but they are at the core of how you access functionality via {{ link title="tags" uri="guides/pyrocms-tags" }}.

All of these plugins are available in PyroCMS Community Edition with the exception of {{ link title="the streams plugin" uri="plugins/streams" }}, which is available as part of the [streams module](https://www.pyrocms.com/store/details/pyrostreams) or as part of [PyroCMS Pro](https://www.pyrocms.com/store/details/pyrocms_professional).

{{ nav:auto start="plugins" }}
