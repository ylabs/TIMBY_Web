# About PyroCMS

PyroCMS is a CMS built on [CodeIgniter](http://codeigniter.com/), an open
source PHP framework. It's easy to learn, easy to build with, and very
developer-friendly!

In this section, you'll find some basic information about PyroCMS, including
your normal stuff like the {{ link uri="reference/license" title="license" }} and
the {{ link uri="reference/changelog" title="changelog" }}. If you want to get
started installing and using PyroCMS, head over to the {{ link uri="getting-started"
title="Getting Started" }} section.

{{ nav:auto start="reference" }}
