# PyroStreams

PyroStreams is a module that allows to create free-form custom data on in your control panel, and then display that data in your layouts using a simple plugin format. PyroStreams comes as a core module on PyroCMS Pro.

* {{ link uri="modules/streams" title="Module Documentation" }}
* {{ link uri="plugins/streams" title="Plugin Documentation" }}