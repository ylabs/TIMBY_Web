# HTML Widget

The HTML Widget allows for the display of a block of HTML content.

## Fields

<table cellpadding="0" cellspacing="0">
	<tbody>
		<tr>
			<th width="20%">Field</th>
			<th>Notes</th>
		</tr>
		<tr>
			<td>Title</td>
			<td>Widget instance title.</td>
		</tr>
		<tr>
			<td>HTML</td>
			<td>The HTML content to display.</td>
		</tr>
	</tbody>
</table>