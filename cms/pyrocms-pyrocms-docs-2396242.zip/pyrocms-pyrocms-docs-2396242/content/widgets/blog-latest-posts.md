# Blog Latest Posts Widget

The Blog Latest Posts Widget displays an unordered list of your latest blog posts. Each blog post title links to the blog entry page.

## Fields

<table cellpadding="0" cellspacing="0">
	<tbody>
		<tr>
			<th width="20%">Field</th>
			<th>Notes</th>
		</tr>
		<tr>
			<td>Title</td>
			<td>Widget instance title.</td>
		</tr>
		<tr>
			<td>Number to display</td>
			<td>The number of latest blog posts to display.</td>
		</tr>
	</tbody>
</table>