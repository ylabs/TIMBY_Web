# Social Bookmark Widget

The social bookmark widget displays social bookmark tools from [addthis](http://www.addthis.com/). The tools are:

* Email
* Print
* Twitter
* Facebook
* MySpace
* Stumbleupon
* Digg

There is also a link for "More Destinations".

## Fields

<table cellpadding="0" cellspacing="0">
	<tbody>
		<tr>
			<th width="20%">Field</th>
			<th>Notes</th>
		</tr>
		<tr>
			<td>Title</td>
			<td>Widget instance title.</td>
		</tr>
		<tr>
			<td>Mode</td>
			<td>The display mode of the bookmarks: Default (horizontal), Vertical, or Two Columns</td>
		</tr>
	</tbody>
</table>