# Blog Categories Widget

The Blog Categories Widget displays an unordered list of your blog categories. Each category links to its blog category archive page.

## Fields

<table cellpadding="0" cellspacing="0">
	<tbody>
		<tr>
			<th>Field</th>
			<th>Notes</th>
		</tr>
		<tr>
			<td width="20%">Title</td>
			<td>Widget instance title.</td>
		</tr>
	</tbody>
</table>