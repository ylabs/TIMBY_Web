# Login Widget

The login widget displays a simple login box.

## Fields

<table cellpadding="0" cellspacing="0">
	<tbody>
		<tr>
			<th width="20%">Field</th>
			<th>Notes</th>
		</tr>
		<tr>
			<td>Title</td>
			<td>Widget instance title.</td>
		</tr>
	</tbody>
</table>