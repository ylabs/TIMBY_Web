# Twitter Widget

The Twitter widget diplays tweets from a specific user.

## Fields

<table cellpadding="0" cellspacing="0">
	<tbody>
		<tr>
			<th width="20%">Field</th>
			<th>Notes</th>
		</tr>
		<tr>
			<td>Title</td>
			<td>Widget instance title.</td>
		</tr>
		<tr>
			<td>Username</td>
			<td>The twitter handle to show tweets from.</td>
		</tr>
		<tr>
			<td>Number of items</td>
			<td>Number of tweets to show.</td>
		</tr>
	</tbody>
</table>