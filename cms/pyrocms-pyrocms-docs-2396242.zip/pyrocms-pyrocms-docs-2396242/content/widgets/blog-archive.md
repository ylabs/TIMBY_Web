# Blog Archive Widget

The Blog Archive Widget displays an unordered list of archives for your post. Each link is formatted as **Month Name Year** and links to their respective blog archive page.

## Fields

<table cellpadding="0" cellspacing="0">
	<tbody>
		<tr>
			<th>Field</th>
			<th>Notes</th>
		</tr>
		<tr>
			<td width="20%">Title</td>
			<td>Widget instance title.</td>
		</tr>
	</tbody>
</table>