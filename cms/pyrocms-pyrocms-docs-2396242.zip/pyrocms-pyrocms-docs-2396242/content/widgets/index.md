# Widgets

Widgets are little chunks of code that are each designed to do a very specific thing. You can use them by creating widget "instances" and the and then adding that instance to your template code with PyroCMS tags.

The following widgets come with the default install of PyroCMS:

{{ nav:auto start="widgets" }}