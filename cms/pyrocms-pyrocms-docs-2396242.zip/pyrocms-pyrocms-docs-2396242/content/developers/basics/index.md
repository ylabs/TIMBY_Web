# Basics

PyroCMS has some basic concepts that you should be familiar with before delving into development. The following sections will get you started:

{{ nav:auto start="developers/basics" }}