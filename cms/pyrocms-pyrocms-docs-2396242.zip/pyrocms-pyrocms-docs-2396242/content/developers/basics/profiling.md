# Profiling Your Site

You can activate the CodeIgniter profiler at any time if you are logged in as an Admin by adding **?_debug** to the end of your URL:

	http://example.com/?_debug