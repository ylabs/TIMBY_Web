# Sample Module

We've made a sample PyroCMS module [available on GitHub](https://github.com/pyrocms/sample).