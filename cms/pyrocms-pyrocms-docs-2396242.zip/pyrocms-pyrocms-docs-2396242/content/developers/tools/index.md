# Tools

PyroCMS has some handy built in tools (on top of the stock [CodeIgniter tools](http://codeigniter.com/user_guide/overview/features.html)) to make developing with PyroCMS a little easier. They range from our own {{ link title="assets class" uri="developers/tools/assets" }} to the {{ link title="streams API" uri="developers/tools/streams-api" }}:

{{ nav:auto start="developers/tools" }}