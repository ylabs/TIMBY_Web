# Theming Guide

PyroCMS is theme-based, so all of your site's assets go into a theme folder (CSS, JS, layouts, etc). Themes are very easy to create and require no PHP skills - check out the sections below to get started! 

{{ nav:auto start="guides/themes" }}