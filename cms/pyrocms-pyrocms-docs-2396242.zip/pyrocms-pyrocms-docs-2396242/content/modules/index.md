# Core Modules

Below are the core modules that come with the default install of PyroCMS.

Note that **Streams** comes with {{ link ur="pro" title="PyroCMS Pro" }} or can be purchased separately as a module.

</div>
<div class="doc_content">

{{ nav:auto start="modules" }}