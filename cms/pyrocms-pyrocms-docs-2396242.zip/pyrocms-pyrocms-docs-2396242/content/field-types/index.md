# Field Types

Field types are used with {{ link title="Streams" uri="concepts/streams" }} and contain the logic to enter, store, and display data. You can use them with any streams-enabled part of PyroCMS, like the users module.

The following field types with the default install of PyroCMS:

{{ nav:auto start="field-types" }}