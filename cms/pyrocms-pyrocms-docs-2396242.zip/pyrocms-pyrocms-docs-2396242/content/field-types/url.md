# URL Field Type

The URL field type is the same as a text field, but it validates the input to make sure it is a URL.

## Parameters
 
There are no parameters for the URL field type.
 
## Output 
 
The URL field simply outputs the URL input.