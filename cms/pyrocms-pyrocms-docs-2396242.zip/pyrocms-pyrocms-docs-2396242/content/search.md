# Search

We are using Google Site Search as an experimental docs search. Keep in mind that Google needs to index the pages for them to show up, so some new pages may not be searchable yet.

<gcse:searchbox></gcse:searchbox>
<gcse:searchresults></gcse:searchresults> 
