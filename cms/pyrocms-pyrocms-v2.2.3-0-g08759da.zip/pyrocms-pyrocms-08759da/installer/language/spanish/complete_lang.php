<?php defined('BASEPATH') or exit('No direct script access allowed');

# labels
$lang['congrats']		= 'Felicitaciones';
$lang['intro_text']		= 'PyroCMS está instalado y listo para visitar! Por favor ingrese al panel de administración con la siguiente información.';
$lang['email']			= 'E-mail';
$lang['password']		= 'Contraseña';
$lang['show_password']		= 'Show Password?'; #translate
$lang['outro_text']		= 'Finalmente, <strong>elimina el instalador de su servidor</strong> pues si lo dejas puede ser usado para hackear tu sitio web.';

$lang['go_website']		= 'Ir al Sitio Web';
$lang['go_control_panel']	= 'Ir al Panel de Control';
