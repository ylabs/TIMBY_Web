<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['header']		=	'Sveiki';
$lang['thankyou']	= 	'Dėkojame, kad išsirinkote PyroCMS!';
$lang['text']		=	'Idiegti PyroCMS yra iš tiesu lengva, tiesiog vykdykite nurodytus veiksmus. Iškilus problemoms nebijokite, instaliavimo vedlys pasakys kur yra problemos ir ką reikia padaryti.';
$lang['step1'] 		= 'Žingsnis 1';
$lang['link']		= 'Pereiti prie pirmo žingsnio';