<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['header']		=	'Xin chào';
$lang['thankyou']	= 	'Cám ơn đã sử dụng PyroCMS!';
$lang['text']		=	'Cài đặt PyroCMS rất đơn giản, hãy theo các bước hướng dẫn trên màn hình. Nếu có bất kỳ lỗi phát sinh trong quá trình cài đặt, trình cài đặt sẽ hướng dẫn bạn chi tiết để xử lý.';
$lang['step1'] 		= 'Bước 1';
$lang['link']		= 'Bắt đầu cài dặt';