<?php defined('BASEPATH') or exit('No direct script access allowed');

// labels
$lang['congrats']			=	'恭喜您';
$lang['intro_text']			=	'PyroCMS 已經安裝完成！請使用下列資訊登入管理區。';
$lang['email']				=	'電子郵件';
$lang['password']			=	'密碼';
$lang['show_password']		= 	'顯示密碼？';
$lang['outro_text']			=	'最後, <strong>請即刻將安裝目錄從您的伺服器上刪除</strong>。如果將之留在伺服器上，有心人士將可用來侵入您的網站。';

$lang['go_website']			= 	'進入前端網站';
$lang['go_control_panel']	= 	'進入後端系統';