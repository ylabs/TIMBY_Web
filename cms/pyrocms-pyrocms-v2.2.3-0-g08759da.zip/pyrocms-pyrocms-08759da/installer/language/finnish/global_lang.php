<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['intro']	=	'Alku';
$lang['step1']	=	'Vaihe #1';
$lang['step2']	=	'Vaihe #2';
$lang['step3']	=	'Vaihe #3';
$lang['step4']	=	'Vaihe #4';
$lang['final']	=	'Loppu';

$lang['installer.passwords_match']		= 'Salasanat täsmäävät.';
$lang['installer.passwords_dont_match']	= 'Salasanat eivät täsmää.';