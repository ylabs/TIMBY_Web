<?php defined('BASEPATH') or exit('No direct script access allowed');

// labels
$lang['congrats']			= 'Onnittelut';
$lang['intro_text']			= 'PyroCMS on nyt asennettu ja valmis käyttöön! Ole hyvä ja kirjaudu hallintapaneeliin seuraavilla tiedoilla.';
$lang['email']				= 'Sähköposti';
$lang['password']			= 'Salasana';
$lang['show_password']		= 'Näytä salasana?';
$lang['outro_text']			= 'Lopuksi, <strong>poista installer kansio palvelimeltasi</strong>, muuten sitä voidaan käyttää hyväksi sivuston murtautunista varten.';

$lang['go_website']			= 'Mene sivuille';
$lang['go_control_panel']	= 'Mene hallintapaneeliin';