<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['intro']	=	'Pozdrav';
$lang['step1']	=	'Korak #1';
$lang['step2']	=	'Korak #2';
$lang['step3']	=	'Korak #3';
$lang['step4']	=	'Korak #4';
$lang['final']	=	'Zaključek';

$lang['installer.passwords_match']		= "Gesli se ujemata.";
$lang['installer.passwords_dont_match']	= "Gesli se ne ujemata";