<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['header']	  = 'Willkomen';
$lang['thankyou'] = 'Vielen Dank, dass Sie sich f&uuml;r das PyroCMS entschieden haben.';
$lang['text']	  = 'Es ist sehr einfach das PyroCMS zu Installieren - Folge einfach den folgenden Schritten und Anweisungen.';
$lang['step1'] 	  = 'Schritt 1';
$lang['link']	  = 'Beginn mit dem ersten Schritt.';
