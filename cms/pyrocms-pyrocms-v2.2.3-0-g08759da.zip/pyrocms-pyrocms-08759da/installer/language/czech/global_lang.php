<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['intro']	=	'Intro';
$lang['step1']	=	'Krok #1';
$lang['step2']	=	'Krok #2';
$lang['step3']	=	'Krok #3';
$lang['step4']	=	'Krok #4';
$lang['final']	=	'Poslední krok';

$lang['installer.passwords_match']		= 'Hesla se shodují.';
$lang['installer.passwords_dont_match']	= 'Hesla se neshodují.';