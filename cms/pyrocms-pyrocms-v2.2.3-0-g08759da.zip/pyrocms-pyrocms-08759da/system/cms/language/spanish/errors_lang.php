<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Error 404
$lang['error_404_title']	= 'Página no encontrada';
$lang['error_404_message']	= 'No pudimos encontrar la página que estabas buscando. <a href="%s">Ir a la página principal</a>.';

// Database
$lang['error_invalid_db_group']	= 'El grupo de configuración de la base de datos es incorrecto "%s".';

/* End of file errors_lang.php */