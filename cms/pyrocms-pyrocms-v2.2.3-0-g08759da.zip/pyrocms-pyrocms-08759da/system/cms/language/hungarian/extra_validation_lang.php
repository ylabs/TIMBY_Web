<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash']      = "A(z) %s mező csak az angol abc betűit, számokat, aláhúzáskaraktert, pontot és kötőjelet fogad el!";
$lang['decimal']             = "A(z) %s mező csak számot fogad el!";
$lang['csrf_bad_token']      = "Hibás CSRF jel";

/* End of file extra_validation_lang.php */