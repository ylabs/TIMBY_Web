<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Error 404
$lang['error_404_title'] = 'पृष्ठ लापता';
$lang['error_404_message'] = 'आप जिस पृष्ठ को इस्तेमाल करना  चाह रहे हें वो ईस्वक्त मौजूद नहीं हैं। कृपया करके हरामे <a href="%s">मुख्य पृष्ठ</a> पे प्रस्तान करें।';

// Database
$lang['error_invalid_db_group'] = 'डेटाबेस "%s" गलत समूह इस्तेमाल कर रहा हैं।';

/* End of file errors_lang.php */