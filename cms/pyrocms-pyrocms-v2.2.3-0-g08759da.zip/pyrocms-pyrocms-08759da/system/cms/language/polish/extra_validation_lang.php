<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash']			= "Pole %s może zawierać tylko znaki alfanumeryczne, podkreślenie, kropkę i myślnik.";
$lang['decimal']				= "Pole %s może zawierać tylko liczbę dziesiętną.";
$lang['csrf_bad_token']			= "Nieprawidłowy token CSRF";

/* End of file extra_validation_lang.php */